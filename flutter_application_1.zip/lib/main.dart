import 'package:flutter/material.dart';
import './jokes_app.dart';

main() {
  runApp(JokesApp());
}
